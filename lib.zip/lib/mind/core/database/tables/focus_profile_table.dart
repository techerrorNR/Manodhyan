/*
 *
 *  * Copyright (c) 2024 ManoDhyan (https://github.com/techerrorNR)
 *  * Author : Rakesh Yadav (https://github.com/techerrorNR/Manodhyan)
 *  *
 *  * This source code is licensed under the GPL-2.0 license license found in the
 *  * LICENSE file in the root directory of this source tree.
 *
 */

import 'dart:convert';

import 'package:drift/drift.dart';
import 'package:manodhyan/mind/core/database/converters/string_list_converter.dart';
import 'package:manodhyan/mind/core/enums/session_type.dart';

@DataClassName("FocusProfile")
class FocusProfileTable extends Table {
  /// Selected session type
  IntColumn get sessionType => intEnum<SessionType>()();

  @override
  Set<Column<Object>>? get primaryKey => {sessionType};

  /// Duration in SECONDS for the focus session
  IntColumn get sessionDuration => integer().withDefault(const Constant(0))();

  /// Flag indicating if to enforce the session or not.
  /// If 'True' user cannot end session until the time ends.
  BoolColumn get enforceSession =>
      boolean().withDefault(const Constant(false))();

  /// Flag indicating if to start DND during the focus session
  BoolColumn get shouldStartDnd =>
      boolean().withDefault(const Constant(false))();

  /// List of app's packages which are selected as distracting apps.
  TextColumn get distractingApps => text()
      .map(const StringListConverter())
      .withDefault(Constant(jsonEncode([])))();
}
