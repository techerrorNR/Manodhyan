// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'unique_records_dao.dart';

// ignore_for_file: type=lint
mixin _$UniqueRecordsDaoMixin on DatabaseAccessor<AppDatabase> {
  UniqueRecordsDaoManager get managers => UniqueRecordsDaoManager(this);
}

class UniqueRecordsDaoManager {
  final _$UniqueRecordsDaoMixin _db;
  UniqueRecordsDaoManager(this._db);
}
