/*
 *
 *  * Copyright (c) 2024 ManoDhyan (https://github.com/techerrorNR)
 *  * Author : Rakesh Yadav (https://github.com/techerrorNR/Manodhyan)
 *  *
 *  * This source code is licensed under the GPL-2.0 license license found in the
 *  * LICENSE file in the root directory of this source tree.
 *
 */

import 'package:flutter/material.dart';
import 'package:manodhyan/mind/core/enums/item_position.dart';
import 'package:manodhyan/mind/core/extensions/ext_num.dart';
import 'package:manodhyan/mind/core/utils/widget_utils.dart';
import 'package:manodhyan/mind/ui/common/rounded_container.dart';
import 'package:manodhyan/mind/ui/common/styled_text.dart';

/// Global list tile used throughout the app
///
/// Alternative to [ListTile] as the list tile widget have some artifact when scrolling while in focus state
class DefaultListTile extends StatelessWidget {
  const DefaultListTile({
    super.key,
    this.leading,
    this.title,
    this.subtitle,
    this.trailing,
    this.leadingIcon,
    this.titleText,
    this.subtitleText,
    this.color,
    this.accent,
    this.onPressed,
    this.switchValue,
    this.isSelected,
    this.position,
    this.margin,
    this.enabled = true,
    this.isPrimary = false,
  });

  final Widget? leading;
  final Widget? title;
  final Widget? subtitle;
  final Widget? trailing;
  final IconData? leadingIcon;
  final String? titleText;
  final String? subtitleText;
  final Color? color;
  final Color? accent;
  final bool? switchValue;
  final bool? isSelected;
  final ItemPosition? position;
  final VoidCallback? onPressed;
  final bool enabled;
  final bool isPrimary;
  final EdgeInsets? margin;

  @override
  Widget build(BuildContext context) {
    return RoundedContainer(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      margin: margin ?? const EdgeInsets.only(top: 4),
      borderRadius: getBorderRadiusFromPosition(position ?? ItemPosition.none),
      color:
          isPrimary ? Theme.of(context).colorScheme.secondaryContainer : color,
      onPressed: enabled ? onPressed : null,
      child: Row(
        mainAxisSize: MainAxisSize.max,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          /// Leading widget
          leadingIcon != null
              ? Icon(
                  leadingIcon,
                  color: enabled
                      ? accent
                      : isPrimary
                          ? Theme.of(context).colorScheme.secondaryContainer
                          : Theme.of(context).hintColor,
                )
              : leading ?? 0.hBox,

          /// leading space
          if (leading != null || leadingIcon != null) const SizedBox(width: 16),
          Expanded(
            child: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  /// Title widget
                  titleText != null
                      ? StyledText(
                          titleText!,
                          fontSize: 16,
                          fontWeight: isPrimary ? FontWeight.w500 : null,
                          color: enabled ? accent : Theme.of(context).hintColor,
                        )
                      : title ?? 0.vBox,

                  /// Subtitle widget
                  subtitleText != null
                      ? StyledText(
                          subtitleText!,
                          fontSize: 14,
                          isSubtitle: true,
                        )
                      : subtitle ?? 0.vBox,
                ],
              ),
            ),
          ),

          if (switchValue != null || isSelected != null || trailing != null)
            4.hBox,

          /// Trailing widget
          switchValue != null
              ? IgnorePointer(
                  child: Switch(
                    value: switchValue ?? false,
                    splashRadius: 0,
                    materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                    onChanged: enabled ? (_) {} : null,
                  ),
                )
              : isSelected != null
                  ? IgnorePointer(
                      child: Checkbox(
                        value: isSelected,
                        splashRadius: 0,
                        materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                        onChanged: enabled ? (_) {} : null,
                      ),
                    )
                  : trailing ?? 0.hBox,
        ],
      ),
    );
  }
}
