/*
 *
 *  * Copyright (c) 2024 ManoDhyan (https://github.com/techerrorNR)
 *  * Author : Rakesh Yadav (https://github.com/techerrorNR/Manodhyan)
 *  *
 *  * This source code is licensed under the GPL-2.0 license license found in the
 *  * LICENSE file in the root directory of this source tree.
 *
 */

import 'package:fluentui_system_icons/fluentui_system_icons.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:manodhyan/mind/core/extensions/ext_build_context.dart';
import 'package:manodhyan/mind/config/hero_tags.dart';
import 'package:manodhyan/mind/providers/notifications/notification_settings_provider.dart';
import 'package:manodhyan/mind/providers/system/permissions_provider.dart';
import 'package:manodhyan/mind/ui/common/default_fab_button.dart';
import 'package:manodhyan/mind/ui/dialogs/input_field_dialog.dart';

class NewNotificationScheduleFab extends ConsumerWidget {
  const NewNotificationScheduleFab({super.key});

  void _onPressed(BuildContext context, WidgetRef ref) async {
    final scheduleName = await showNotificationScheduleNameDialog(
      context: context,
      heroTag: HeroTags.newNotificationScheduleFABTag,
    );

    if (scheduleName == null || scheduleName.isEmpty) return;

    /// Create new schedule
    ref
        .read(notificationSettingsProvider.notifier)
        .createNewSchedule(scheduleName);
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final havePermission = ref.watch(
        permissionProvider.select((v) => v.haveNotificationAccessPermission));

    return havePermission
        ? DefaultFabButton(
            heroTag: HeroTags.newNotificationScheduleFABTag,
            label: context.locale.new_schedule_fab_button,
            icon: FluentIcons.add_20_filled,
            onPressed: () => _onPressed(context, ref),
          )
        : const SizedBox.shrink();
  }
}
