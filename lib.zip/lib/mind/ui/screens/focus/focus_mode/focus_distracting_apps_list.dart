/*
 *
 *  * Copyright (c) 2024 ManoDhyan (https://github.com/techerrorNR)
 *  * Author : Rakesh Yadav (https://github.com/techerrorNR/Manodhyan)
 *  *
 *  * This source code is licensed under the GPL-2.0 license license found in the
 *  * LICENSE file in the root directory of this source tree.
 *
 */

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:manodhyan/mind/core/extensions/ext_build_context.dart';
import 'package:manodhyan/mind/providers/focus/focus_mode_provider.dart';
import 'package:manodhyan/mind/ui/common/sliver_distracting_apps_list.dart';

class FocusDistractingAppsList extends ConsumerWidget {
  const FocusDistractingAppsList({
    super.key,
  });

  void _onDistractingAppsChanged(
    BuildContext context,
    WidgetRef ref,
    String package,
    bool isSelected,
  ) async {
    // User want to remove app from list and session is active
    if (!isSelected &&
        ref.read(focusModeProvider).activeSession.value != null) {
      context.showSnackAlert(
        context.locale.focus_distracting_apps_removal_snack_alert,
      );
      return;
    }

    // User want to add app to list
    ref
        .read(focusModeProvider.notifier)
        .insertRemoveDistractingApp(package, isSelected);
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final distractingApps = ref
        .watch(focusModeProvider.select((v) => v.focusProfile.distractingApps));

    return SliverDistractingAppsList(
      distractingApps: distractingApps,
      isInsideModalSheet: false,
      onSelectionChanged: (package, isSelected) => _onDistractingAppsChanged(
        context,
        ref,
        package,
        isSelected,
      ),
    );
  }
}
