/*
 *
 *  * Copyright (c) 2024 ManoDhyan (https://github.com/techerrorNR)
 *  * Author : Rakesh Yadav (https://github.com/techerrorNR/Manodhyan)
 *  *
 *  * This source code is licensed under the GPL-2.0 license license found in the
 *  * LICENSE file in the root directory of this source tree.
 *
 */

import 'package:flutter_animate/flutter_animate.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:manodhyan/mind/core/database/app_database.dart';
import 'package:manodhyan/mind/core/database/daos/dynamic_records_dao.dart';
import 'package:manodhyan/mind/core/enums/session_state.dart';
import 'package:manodhyan/mind/core/extensions/ext_date_time.dart';
import 'package:manodhyan/mind/core/services/drift_db_service.dart';
import 'package:manodhyan/mind/core/utils/date_time_utils.dart';
import 'package:manodhyan/mind/models/dated_focus_model.dart';
import 'package:manodhyan/mind/providers/focus/focus_mode_provider.dart';

/// A Riverpod state notifier provider that manages [DatedFocusModel].
final datedFocusProvider =
    StateNotifierProvider.family<FocusModeNotifier, DatedFocusModel, DateTime>(
  (ref, day) {
    if (day == dateToday) {
      ref.watch(focusModeProvider.select((v) => v.activeSession));
    }
    return FocusModeNotifier(day);
  },
);

/// This class manages the state of Focus Timeline.
class FocusModeNotifier extends StateNotifier<DatedFocusModel> {
  late DynamicRecordsDao _dao;
  final DateTime selectedDay;

  FocusModeNotifier(this.selectedDay) : super(const DatedFocusModel()) {
    _dao = DriftDbService.instance.driftDb.dynamicRecordsDao;
    refreshTimeline();
  }

  /// Refresh the state
  Future<void> refreshTimeline({DateTime? date}) async {
    // Start of the day
    final startOfDay = (date ?? selectedDay).dateOnly;

    // End of the day
    final endOfDay = startOfDay.copyWith(
      hour: 23,
      minute: 59,
      second: 59,
      millisecond: 999,
    );

    var sessions = await _dao.fetchAllSessionsForInterval(
      start: startOfDay,
      end: endOfDay,
    );

    final todaysFocusedTime = sessions
        .fold(
          0,
          (prev, e) =>
              prev + (e.state == SessionState.active ? 0 : e.durationSecs),
        )
        .seconds;

    state = state.copyWith(
      selectedDaysSessions: AsyncData(sessions),
      selectedDaysFocusedTime: todaysFocusedTime,
    );
  }

  /// Update the session and refresh the timeline
  void updateSession(FocusSession session) async {
    await DriftDbService.instance.driftDb.dynamicRecordsDao
        .updateFocusSessionById(session);

    await refreshTimeline(date: session.startDateTime.dateOnly);
  }
}
