/*
 *
 *  * Copyright (c) 2024 ManoDhyan (https://github.com/techerrorNR)
 *  * Author : Rakesh Yadav (https://github.com/techerrorNR/Manodhyan)
 *  *
 *  * This source code is licensed under the GPL-2.0 license license found in the
 *  * LICENSE file in the root directory of this source tree.
 *
 */

import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:manodhyan/mind/core/database/adapters/time_of_day_adapter.dart';
import 'package:manodhyan/mind/core/database/app_database.dart';
import 'package:manodhyan/mind/core/extensions/ext_date_time.dart';
import 'package:manodhyan/mind/core/services/drift_db_service.dart';
import 'package:manodhyan/mind/core/utils/default_models_utils.dart';

/// A Riverpod state notifier provider that manages [ParentalControls]
final parentalControlsProvider =
    StateNotifierProvider<ParentalControlsNotifier, ParentalControls>(
  (ref) => ParentalControlsNotifier(),
);

class ParentalControlsNotifier extends StateNotifier<ParentalControls> {
  /// Returns `TRUE` if the time now is between the uninstall window otherwise `FALSE`.
  bool get isBetweenUninstallWindow => DateTime.now().isBetweenTod(
        state.uninstallWindowTime,
        TimeOfDayAdapter.fromMinutes(state.uninstallWindowTime.toMinutes + 10),
      );

  /// Returns `TRUE` if the time now is between the invincible window otherwise `FALSE`.
  bool get isBetweenInvincibleWindow => DateTime.now().isBetweenTod(
        state.invincibleWindowTime,
        TimeOfDayAdapter.fromMinutes(state.invincibleWindowTime.toMinutes + 10),
      );

  ParentalControlsNotifier() : super(defaultParentalControlsModel) {
    init();
  }

  /// Initializes the settings state by loading from the database and setting up a listener for saving changes.
  Future<ParentalControls> init() async {
    final dao = DriftDbService.instance.driftDb.uniqueRecordsDao;
    state = await dao.loadParentalControls();

    /// Listen to provider and save changes to Isar database
    addListener(
      fireImmediately: false,
      (state) => dao.saveParentalControls(state),
    );

    return state;
  }

  /// Switch protected access
  void switchProtectedAccess() =>
      state = state.copyWith(protectedAccess: !state.protectedAccess);

  /// Changes the time of day when uninstall widow starts for 5 minutes.
  void changeUninstallWindowTime(TimeOfDayAdapter time) =>
      state = state.copyWith(uninstallWindowTime: time);

  /// Changes the time of day when invincible widow starts for 5 minutes.
  void changeInvincibleWindowTime(TimeOfDayAdapter time) =>
      state = state.copyWith(invincibleWindowTime: time);

  void switchInvincibleMode() =>
      state = state.copyWith(isInvincibleModeOn: !state.isInvincibleModeOn);

  void toggleIncludeAppsTimer() =>
      state = state.copyWith(includeAppsTimer: !state.includeAppsTimer);

  void toggleIncludeAppsLaunchLimit() => state =
      state.copyWith(includeAppsLaunchLimit: !state.includeAppsLaunchLimit);

  void toggleIncludeAppsActivePeriod() => state =
      state.copyWith(includeAppsActivePeriod: !state.includeAppsActivePeriod);

  void toggleIncludeGroupsTimer() =>
      state = state.copyWith(includeGroupsTimer: !state.includeGroupsTimer);

  void toggleIncludeGroupsActivePeriod() => state = state.copyWith(
      includeGroupsActivePeriod: !state.includeGroupsActivePeriod);

  void toggleIncludeShortsTimer() =>
      state = state.copyWith(includeShortsTimer: !state.includeShortsTimer);

  void toggleIncludeBedtimeSchedule() => state =
      state.copyWith(includeBedtimeSchedule: !state.includeBedtimeSchedule);
}
