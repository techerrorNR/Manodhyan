/*
 *
 *  * Copyright (c) 2024 ManoDhyan (https://github.com/techerrorNR)
 *  * Author : Rakesh Yadav (https://github.com/techerrorNR/Manodhyan)
 *  *
 *  * This source code is licensed under the GPL-2.0 license license found in the
 *  * LICENSE file in the root directory of this source tree.
 *
 */

import 'package:flutter_animate/flutter_animate.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:manodhyan/mind/core/database/app_database.dart';
import 'package:manodhyan/mind/core/services/drift_db_service.dart';
import 'package:manodhyan/mind/core/services/method_channel_service.dart';
import 'package:manodhyan/mind/core/utils/default_models_utils.dart';

/// A Riverpod state notifier provider that manages [SharedUniqueData].
final sharedUniqueDataProvider =
    StateNotifierProvider<SharedDataNotifier, SharedUniqueData>(
  (ref) => SharedDataNotifier(),
);

class SharedDataNotifier extends StateNotifier<SharedUniqueData> {
  SharedDataNotifier() : super(defaultSharedUniqueDataModel) {
    init();
  }

  void init() async {
    final dao = DriftDbService.instance.driftDb.uniqueRecordsDao;
    state = await dao.loadSharedData();

    await MethodChannelService.instance.updateExcludedApps(state.excludedApps);

    /// Run after a delay to avoid database deadlock
    /// Listen to provider and save changes to database
    Future.delayed(
      1.seconds,
      () => addListener(
        fireImmediately: false,
        (state) => dao.saveSharedData(state),
      ),
    );
  }

  /// Include or Exclude an app from total usage statistics
  void includeExcludeApp(String appPackage, bool shouldInclude) async {
    state = state.copyWith(
      excludedApps: shouldInclude
          ? [...state.excludedApps, appPackage]
          : [...state.excludedApps.where((e) => e != appPackage)],
    );

    await MethodChannelService.instance.updateExcludedApps(state.excludedApps);
  }
}
